<?php

$url_admin='http://'.$_SERVER['SERVER_NAME'].'/admin/';



?>

