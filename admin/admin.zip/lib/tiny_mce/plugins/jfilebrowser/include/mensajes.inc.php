<?php 

/*
 * $Id: jFileBrowser, 2010.
 * @author Juaniquillo
 * @copyright Copyright � 2010, Victor Sanchez (Juaniquillo).
 * @email juaniquillo@gmail.com
 * @website http://juaniquillo.com
*/

$mensaje_glob_v[1]= "<li>El nombre es requerido<li>";//
$mensaje_glob_v[2]="<li>Favor de indicar el directorio</li>";//
$mensaje_glob_v[3]="<li>Favor de escoger una imagen</li>";//
$mensaje_glob_v[4]="<li>S&oacute;lo se pueden subir cinco im&aacute;genes a la vez</li>";
$mensaje_glob_v[5]="<li>Ese tipo de archivo no es permitido</li>";
$mensaje_glob_v[6]="<li>Este archivo es muy grande. Favor de escoger otro</li>";//
$mensaje_glob_v[7]="<li></li>";
$mensaje_glob_v[8]="<li></li>";
$mensaje_glob_v[9]="<li></li>";//
$mensaje_glob_v[10]="<li></li>";
$mensaje_glob_v[11]="<li>Ha ocurrido un error. Por favor intente luego</li>";//

?>